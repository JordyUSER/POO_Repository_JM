/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Components;
import java.awt.Font;

/**
 *
 * @author erick
 */
public class Fonts {
    public static Font title = new Font("arial", Font.BOLD,20);
    public static Font txt = new Font("arial", Font.PLAIN,16);
    public static Font btn = new Font("arial", Font.PLAIN,17);
}
