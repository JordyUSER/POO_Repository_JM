/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Components;

import java.awt.Color;

/**
 *
 * @author erick
 */
public class Colors {
    public static Color white1 = new Color(245,245,245);
    public static Color white2 = new Color(243,243,243);
    public static Color purple1 = new Color(115, 121, 255);
    public static Color purple2 = new Color(143, 115, 255);
}
