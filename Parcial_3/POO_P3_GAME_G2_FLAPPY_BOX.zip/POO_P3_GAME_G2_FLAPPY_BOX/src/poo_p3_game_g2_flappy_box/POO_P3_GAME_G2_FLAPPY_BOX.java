package poo_p3_game_g2_flappy_box;
import Vista.vMenu;

public class POO_P3_GAME_G2_FLAPPY_BOX {

    public static void main(String[] args) {
        vMenu vista = new vMenu();
        vista.setVisible(true);
    }
    
}
